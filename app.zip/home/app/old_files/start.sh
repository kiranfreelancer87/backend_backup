#!/bin/bash
python3 price.py
python3 3.py 0 3999
python3 3.py 3999 7999
python3 3.py 7999 11999
python3 3.py 11999 15999
python3 3.py 15999 19999
python3 3.py 19999 22999

